import Dashboard from '../components/dashboard'
import {Component} from 'react'
import projects from '../static/projects.json'

import { size } from 'polished'
import styled from "styled-components";


// Widgets
// import DateTime from '../components/widgets/datetime'
// import PageSpeedInsightsScore from '../components/widgets/pagespeed-insights/score'
// import PageSpeedInsightsStats from '../components/widgets/pagespeed-insights/stats'
import JiraIssueCount from '../components/widgets/jira/issue-count'
import SonarQube from '../components/widgets/sonarqube'
import Jenkins from '../components/widgets/jenkins'
import BitbucketPullRequestCount from '../components/widgets/bitbucket/pull-request-count'
// import ElasticsearchHitCount from '../components/widgets/elasticsearch/hit-count'
// import GitHubIssueCount from '../components/widgets/github/issue-count'

// Theme
import lightTheme from '../styles/light-theme'
import darkTheme from '../styles/dark-theme'

const StyleWrapper = styled.main`
  ${size('49em')}
  align-items: center;
  background-color: ${props => props.theme.palette.backgroundColor};
  color: ${props => props.theme.palette.textColor};
  display: flex;
  flex-flow: row wrap;
  justify-content: flex-start;
  padding: 0px;
  margin: 1px;
`

const List = [1,2,3]

projects.map(project=>{
  console.log(project.name)
})

export default () => (

  // constructor(props) {
  //   super(props)
  //   this.uploadFile = this.uploadFile.bind(this)
  // }

  // uploadFile = () => {
  //   let file = event.target.files[0]
  //   console.log(file)
  //   if (file) {
  //     let data = new FormData()
  //     data.append('file', file)

  //   }
  // }

  <Dashboard theme={darkTheme}>
    {

      List.map(element=>(
        <StyleWrapper>
          <JiraIssueCount
            title='JIRA Open Bugs'
            authKey='jira'
            url={process.env.CORS_PROXY + '/https://projectportal.elca.ch'}
            query='project = ELCAVNPC AND type = Improvement'
          />

          <BitbucketPullRequestCount
            title='Bitbucket Open PR'
            authKey='bitbucket'
            url={process.env.CORS_PROXY + '/https://git.elcanet.local'}
            project='ELCAVN-MANAGEMENT-TOOL'
            repository='project-wallboard'
          />

          <SonarQube
            authKey='sonarqube'
            url={process.env.CORS_PROXY + '/http://ci.elcanet.local/sonar'}
            componentKey='prj_ofac-portals-sonar'
          />

          <Jenkins
            authKey='jenkins'
            url={process.env.CORS_PROXY + '/http://ci.elcanet.local/jenkins'}
            jobs={[
              { label: 'aaaa', path: 'prj_elca-git-training+build-on-commit' },
              { label: 'bbbb', path: 'prj_elcavn-newcomers+Build+java3' }
            ]}
          />

          </StyleWrapper>
      ))
    }

  </Dashboard>

)
