module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./auth.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  bitbucket: {
    username: "qrv",
    password: "Qu@ng197"
  },
  elasticsearch: {
    username: process.env.ELASTICSEARCH_USER,
    password: process.env.ELASTICSEARCH_PASS
  },
  jenkins: {
    username: "qrv",
    password: "Qu@ng197"
  },
  jira: {
    username: "qrv",
    password: "Qu@ng197"
  },
  sonarqube: {
    username: "qrv",
    password: "Qu@ng197"
  },
  github: {
    username: process.env.GITHUB_USER,
    password: process.env.GITHUB_PASS
  }
});

/***/ }),

/***/ "./components/badge.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_polished__ = __webpack_require__("polished");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_polished___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_polished__);


/* harmony default export */ __webpack_exports__["a"] = (__WEBPACK_IMPORTED_MODULE_0_styled_components___default.a.span.withConfig({
  displayName: "badge",
  componentId: "s1d18iu5-0"
})(["", " background-color:transparent;border-radius:50%;color:", ";display:inline-block;line-height:1.75em;text-align:center;"], Object(__WEBPACK_IMPORTED_MODULE_1_polished__["size"])('1.75em'), function (props) {
  return props.theme.palette.textInvertColor;
}));

/***/ }),

/***/ "./components/circle-progress.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("polished");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_polished__);
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\circle-progress.js";



var Svg = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.svg.withConfig({
  displayName: "circle-progress__Svg",
  componentId: "s1qqr0wc-0"
})(["", " fill:transparent;margin:auto;"], Object(__WEBPACK_IMPORTED_MODULE_2_polished__["size"])('14em'));
var Circle = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.circle.withConfig({
  displayName: "circle-progress__Circle",
  componentId: "s1qqr0wc-1"
})(["stroke-linecap:round;stroke-width:10;transform:translate(100px,100px) rotate(-89.9deg);transition:stroke-dashoffset 0.3s linear;&.background{stroke:", ";}&.progress{stroke:", ";}"], function (props) {
  return props.theme.palette.borderColor;
}, function (props) {
  return props.theme.palette.primaryColor;
});
var Text = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.text.withConfig({
  displayName: "circle-progress__Text",
  componentId: "s1qqr0wc-2"
})(["fill:", ";font-size:4em;text-anchor:middle;"], function (props) {
  return props.theme.palette.textColor;
});
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var _ref$max = _ref.max,
      max = _ref$max === void 0 ? 100 : _ref$max,
      _ref$radius = _ref.radius,
      radius = _ref$radius === void 0 ? 90 : _ref$radius,
      _ref$unit = _ref.unit,
      unit = _ref$unit === void 0 ? '' : _ref$unit,
      value = _ref.value;
  var strokeDasharray = 2 * radius * Math.PI;
  var strokeDashoffset = (max - value) / max * strokeDasharray;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Svg, {
    viewBox: "0 0 200 200",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Circle, {
    r: radius,
    className: "background",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Circle, {
    r: radius,
    className: "progress",
    strokeDasharray: strokeDasharray,
    strokeDashoffset: strokeDashoffset,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Text, {
    x: "100",
    y: "120",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, value, unit));
});

/***/ }),

/***/ "./components/counter.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_components__);
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\counter.js";


var Counter = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.div.withConfig({
  displayName: "counter__Counter",
  componentId: "zarpy5-0"
})(["font-size:4em;color:", ";"], function (props) {
  return props.theme.palette.accentColor;
});
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var value = _ref.value;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Counter, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9
    }
  }, value);
});

/***/ }),

/***/ "./components/dashboard.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_head__ = __webpack_require__("next/head");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_head___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_next_head__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("polished");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_polished__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_styled_components__);
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\dashboard.js";

var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n\n  html {\n    font-family: 'Roboto', sans-serif;\n  }\n"]);



function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }





Object(__WEBPACK_IMPORTED_MODULE_3_styled_components__["injectGlobal"])(_templateObject, Object(__WEBPACK_IMPORTED_MODULE_2_polished__["normalize"])());
var Container = __WEBPACK_IMPORTED_MODULE_3_styled_components___default.a.main.withConfig({
  displayName: "dashboard__Container",
  componentId: "c3g5ri-0"
})(["align-items:center;background-color:", ";color:", ";display:flex;flex-flow:row wrap;justify-content:center;padding:0em;"], function (props) {
  return props.theme.palette.borderColor;
}, function (props) {
  return props.theme.palette.textColor;
});
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var children = _ref.children,
      theme = _ref.theme;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_styled_components__["ThemeProvider"], {
    theme: theme,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_next_head___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("link", {
    href: "https://fonts.googleapis.com/css?family=Roboto:300,400,500",
    rel: "stylesheet",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  })), children));
});

/***/ }),

/***/ "./components/error-icon.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("polished");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_polished__);
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\error-icon.js";



var Svg = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.svg.withConfig({
  displayName: "error-icon__Svg",
  componentId: "atlljz-0"
})(["", " fill:", ";"], Object(__WEBPACK_IMPORTED_MODULE_2_polished__["size"])('5em'), function (props) {
  return props.theme.palette.errorColor;
});
/* harmony default export */ __webpack_exports__["a"] = (function () {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Svg, {
    viewBox: "0 0 24 24",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("path", {
    d: "M0 0h24v24H0V0z",
    fill: "none",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("path", {
    d: "M11 15h2v2h-2zm0-8h2v6h-2zm.99-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    }
  }));
});

/***/ }),

/***/ "./components/loading-indicator.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_components__);
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\loading-indicator.js";


var rotation = Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["keyframes"])(["0%{transform:rotate(0deg);}100%{transform:rotate(270deg);}"]);
var turn = Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["keyframes"])(["0%{stroke-dashoffset:187;}50%{stroke-dashoffset:46.75;transform:rotate(135deg);}100%{stroke-dashoffset:187;transform:rotate(450deg);}"]);
var Svg = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.svg.withConfig({
  displayName: "loading-indicator__Svg",
  componentId: "s4g2zu2-0"
})(["animation:", " 1.4s linear infinite;height:", ";width:", ";"], rotation, function (props) {
  return props.size;
}, function (props) {
  return props.size;
});
var Circle = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.circle.withConfig({
  displayName: "loading-indicator__Circle",
  componentId: "s4g2zu2-1"
})(["animation:", " 1.4s ease-in-out infinite;fill:none;stroke:", ";stroke-dasharray:187;stroke-dashoffset:0;stroke-linecap:round;stroke-width:6;transform-origin:center;"], turn, function (props) {
  return props.theme.palette.primaryColor;
});
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size;
  var svgSize = size === 'small' ? '1.75em' : '5em';
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Svg, {
    viewBox: "0 0 66 66",
    size: svgSize,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Circle, {
    cx: "33",
    cy: "33",
    r: "30",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }));
});

/***/ }),

/***/ "./components/table.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Th; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Td; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_components__);

/* harmony default export */ __webpack_exports__["c"] = (__WEBPACK_IMPORTED_MODULE_0_styled_components___default.a.table.withConfig({
  displayName: "table",
  componentId: "s1pzdxv7-0"
})(["border-spacing:0.75em;"]));
var Th = __WEBPACK_IMPORTED_MODULE_0_styled_components___default.a.th.withConfig({
  displayName: "table__Th",
  componentId: "s1pzdxv7-1"
})(["text-align:right;"]);
var Td = __WEBPACK_IMPORTED_MODULE_0_styled_components___default.a.td.withConfig({
  displayName: "table__Td",
  componentId: "s1pzdxv7-2"
})(["text-align:left;"]);

/***/ }),

/***/ "./components/widget.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("polished");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_polished__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__loading_indicator__ = __webpack_require__("./components/loading-indicator.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__error_icon__ = __webpack_require__("./components/error-icon.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widget.js";





var Container = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.div.withConfig({
  displayName: "widget__Container",
  componentId: "rztqo9-0"
})(["", " align-items:center;background-color:", ";border:1px solid ", ";display:flex;flex-direction:column;justify-content:center;margin:1em 1em 1em 2em;padding:1em;"], Object(__WEBPACK_IMPORTED_MODULE_2_polished__["size"])('19em'), function (props) {
  return props.theme.palette.canvasColor;
}, function (props) {
  return props.theme.palette.borderColor;
});
var Title = __WEBPACK_IMPORTED_MODULE_1_styled_components___default.a.h1.withConfig({
  displayName: "widget__Title",
  componentId: "rztqo9-1"
})(["text-align:center;"]);
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var children = _ref.children,
      _ref$error = _ref.error,
      error = _ref$error === void 0 ? false : _ref$error,
      _ref$loading = _ref.loading,
      loading = _ref$loading === void 0 ? false : _ref$loading,
      _ref$title = _ref.title,
      title = _ref$title === void 0 ? '' : _ref$title;
  var content;

  if (loading) {
    content = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__loading_indicator__["a" /* default */], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 26
      }
    });
  } else if (error) {
    content = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__error_icon__["a" /* default */], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 28
      }
    });
  } else {
    content = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 30
      }
    }, children);
  }

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, title ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Title, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, title) : '', content);
});

/***/ }),

/***/ "./components/widgets/bitbucket/pull-request-count.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BitbucketPullRequestCount; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__widget__ = __webpack_require__("./components/widget.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__counter__ = __webpack_require__("./components/counter.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__lib_auth__ = __webpack_require__("./lib/auth.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\bitbucket\\pull-request-count.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }







var schema = Object(__WEBPACK_IMPORTED_MODULE_3_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  project: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  repository: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["number"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])(),
  users: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["array"])().of(Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()),
  authKey: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()
});

var BitbucketPullRequestCount =
/*#__PURE__*/
function (_Component) {
  _inherits(BitbucketPullRequestCount, _Component);

  function BitbucketPullRequestCount() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, BitbucketPullRequestCount);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = BitbucketPullRequestCount.__proto__ || Object.getPrototypeOf(BitbucketPullRequestCount)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        count: 0,
        error: false,
        loading: true
      }
    }), _temp));
  }

  _createClass(BitbucketPullRequestCount, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, authKey, url, project, repository, users, opts, res, json, count;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, authKey = _props.authKey, url = _props.url, project = _props.project, repository = _props.repository, users = _props.users;
                opts = authKey ? {
                  headers: Object(__WEBPACK_IMPORTED_MODULE_6__lib_auth__["a" /* basicAuthHeader */])(authKey)
                } : {};
                _context.prev = 2;
                _context.next = 5;
                return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("".concat(url, "/rest/api/1.0/projects/").concat(project, "/repos/").concat(repository, "/pull-requests?limit=100"), opts);

              case 5:
                res = _context.sent;
                _context.next = 8;
                return res.json();

              case 8:
                json = _context.sent;

                if (users.length) {
                  count = json.values.filter(function (el) {
                    return users.includes(el.user.slug);
                  }).length;
                } else {
                  count = json.size;
                }

                this.setState({
                  count: count,
                  error: false,
                  loading: false
                });
                _context.next = 16;
                break;

              case 13:
                _context.prev = 13;
                _context.t0 = _context["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 16:
                _context.prev = 16;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(16);

              case 19:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 13, 16, 19]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          count = _state.count,
          error = _state.error,
          loading = _state.loading;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__counter__["a" /* default */], {
        value: count,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 72
        }
      }));
    }
  }]);

  return BitbucketPullRequestCount;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(BitbucketPullRequestCount, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 60 * 5,
    title: 'Bitbucket PR Count',
    users: []
  }
});


/***/ }),

/***/ "./components/widgets/datetime/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_tinytime__ = __webpack_require__("tinytime");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_tinytime___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_tinytime__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__widget__ = __webpack_require__("./components/widget.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\datetime\\index.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }





var TimeItem = __WEBPACK_IMPORTED_MODULE_2_styled_components___default.a.div.withConfig({
  displayName: "datetime__TimeItem",
  componentId: "s1ynucdp-0"
})(["font-size:4em;text-align:center;"]);
var DateItem = __WEBPACK_IMPORTED_MODULE_2_styled_components___default.a.div.withConfig({
  displayName: "datetime__DateItem",
  componentId: "s1ynucdp-1"
})(["font-size:1.5em;text-align:center;"]);

var DateTime =
/*#__PURE__*/
function (_Component) {
  _inherits(DateTime, _Component);

  function DateTime() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, DateTime);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = DateTime.__proto__ || Object.getPrototypeOf(DateTime)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        date: new Date()
      }
    }), _temp));
  }

  _createClass(DateTime, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      var interval = this.props.interval;
      this.timeout = setTimeout(function () {
        return _this2.setState({
          date: new Date()
        });
      }, interval);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "render",
    value: function render() {
      var date = this.state.date;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__widget__["a" /* default */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(TimeItem, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        }
      }, __WEBPACK_IMPORTED_MODULE_1_tinytime___default()('{H}:{mm}').render(date)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(DateItem, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        }
      }, __WEBPACK_IMPORTED_MODULE_1_tinytime___default()('{DD}.{Mo}.{YYYY}').render(date)));
    }
  }]);

  return DateTime;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

Object.defineProperty(DateTime, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 10
  }
});


/***/ }),

/***/ "./components/widgets/elasticsearch/hit-count.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__widget__ = __webpack_require__("./components/widget.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__counter__ = __webpack_require__("./components/counter.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__lib_auth__ = __webpack_require__("./lib/auth.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\elasticsearch\\hit-count.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }







var schema = Object(__WEBPACK_IMPORTED_MODULE_3_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().url().required(),
  index: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  query: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["number"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()
});

var ElasticsearchHitCount =
/*#__PURE__*/
function (_Component) {
  _inherits(ElasticsearchHitCount, _Component);

  function ElasticsearchHitCount() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, ElasticsearchHitCount);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = ElasticsearchHitCount.__proto__ || Object.getPrototypeOf(ElasticsearchHitCount)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        count: 0,
        error: false,
        loading: true
      }
    }), _temp));
  }

  _createClass(ElasticsearchHitCount, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, authKey, index, query, url, opts, res, json;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, authKey = _props.authKey, index = _props.index, query = _props.query, url = _props.url;
                opts = authKey ? {
                  headers: Object(__WEBPACK_IMPORTED_MODULE_6__lib_auth__["a" /* basicAuthHeader */])(authKey)
                } : {};
                _context.prev = 2;
                _context.next = 5;
                return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("".concat(url, "/").concat(index, "/_search?q=").concat(query), opts);

              case 5:
                res = _context.sent;
                _context.next = 8;
                return res.json();

              case 8:
                json = _context.sent;
                this.setState({
                  count: json.hits.total,
                  error: false,
                  loading: false
                });
                _context.next = 15;
                break;

              case 12:
                _context.prev = 12;
                _context.t0 = _context["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 15:
                _context.prev = 15;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(15);

              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 12, 15, 18]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          count = _state.count,
          error = _state.error,
          loading = _state.loading;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 63
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__counter__["a" /* default */], {
        value: count,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        }
      }));
    }
  }]);

  return ElasticsearchHitCount;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(ElasticsearchHitCount, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 60 * 5,
    title: 'Elasticsearch Hit Count'
  }
});


/***/ }),

/***/ "./components/widgets/github/issue-count.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__widget__ = __webpack_require__("./components/widget.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__counter__ = __webpack_require__("./components/counter.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__lib_auth__ = __webpack_require__("./lib/auth.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\github\\issue-count.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }







var schema = Object(__WEBPACK_IMPORTED_MODULE_3_yup__["object"])().shape({
  owner: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  repository: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["number"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])(),
  authKey: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()
});

var GitHubIssueCount =
/*#__PURE__*/
function (_Component) {
  _inherits(GitHubIssueCount, _Component);

  function GitHubIssueCount() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, GitHubIssueCount);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = GitHubIssueCount.__proto__ || Object.getPrototypeOf(GitHubIssueCount)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        count: 0,
        error: false,
        loading: true
      }
    }), _temp));
  }

  _createClass(GitHubIssueCount, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, authKey, owner, repository, opts, res, json;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, authKey = _props.authKey, owner = _props.owner, repository = _props.repository;
                opts = authKey ? {
                  headers: Object(__WEBPACK_IMPORTED_MODULE_6__lib_auth__["a" /* basicAuthHeader */])(authKey)
                } : {};
                _context.prev = 2;
                _context.next = 5;
                return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("https://api.github.com/repos/".concat(owner, "/").concat(repository), opts);

              case 5:
                res = _context.sent;
                _context.next = 8;
                return res.json();

              case 8:
                json = _context.sent;
                this.setState({
                  count: json.open_issues_count,
                  error: false,
                  loading: false
                });
                _context.next = 15;
                break;

              case 12:
                _context.prev = 12;
                _context.t0 = _context["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 15:
                _context.prev = 15;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(15);

              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 12, 15, 18]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          count = _state.count,
          error = _state.error,
          loading = _state.loading;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__counter__["a" /* default */], {
        value: count,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 62
        }
      }));
    }
  }]);

  return GitHubIssueCount;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(GitHubIssueCount, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 60 * 5,
    title: 'GitHub Issue Count'
  }
});


/***/ }),

/***/ "./components/widgets/jenkins/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Jenkins; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__widget__ = __webpack_require__("./components/widget.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__table__ = __webpack_require__("./components/table.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__badge__ = __webpack_require__("./components/badge.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__loading_indicator__ = __webpack_require__("./components/loading-indicator.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__lib_auth__ = __webpack_require__("./lib/auth.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\jenkins\\index.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }











var jenkinsBadgeColor = function jenkinsBadgeColor(_ref) {
  var theme = _ref.theme,
      status = _ref.status;

  switch (status) {
    case 'FAILURE':
      return theme.palette.errorColor;

    case 'UNSTABLE':
      return theme.palette.warnColor;

    case 'SUCCESS':
      return theme.palette.successColor;

    case 'ABORTED':
    case 'NOT_BUILT':
      return theme.palette.disabledColor;

    default:
      // null = 'In Progress'
      return 'transparent';
  }
};

var JenkinsBadge = __WEBPACK_IMPORTED_MODULE_3_styled_components___default()(__WEBPACK_IMPORTED_MODULE_7__badge__["a" /* default */]).withConfig({
  displayName: "jenkins__JenkinsBadge",
  componentId: "gicd9l-0"
})(["background-color:", ";"], jenkinsBadgeColor);
var schema = Object(__WEBPACK_IMPORTED_MODULE_4_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])().required(),
  jobs: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["array"])(Object(__WEBPACK_IMPORTED_MODULE_4_yup__["object"])({
    label: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])().required(),
    path: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])().required()
  })).required(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["number"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])(),
  authKey: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])()
});

var Jenkins =
/*#__PURE__*/
function (_Component) {
  _inherits(Jenkins, _Component);

  function Jenkins() {
    var _ref2;

    var _temp, _this;

    _classCallCheck(this, Jenkins);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref2 = Jenkins.__proto__ || Object.getPrototypeOf(Jenkins)).call.apply(_ref2, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        loading: true,
        error: false
      }
    }), _temp));
  }

  _createClass(Jenkins, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee2() {
        var _this3 = this;

        var _props, authKey, jobs, url, opts, builds;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _props = this.props, authKey = _props.authKey, jobs = _props.jobs, url = _props.url;
                opts = authKey ? {
                  headers: Object(__WEBPACK_IMPORTED_MODULE_9__lib_auth__["a" /* basicAuthHeader */])(authKey)
                } : {};
                _context2.prev = 2;
                _context2.next = 5;
                return Promise.all(jobs.map(
                /*#__PURE__*/
                function () {
                  var _ref3 = _asyncToGenerator(
                  /*#__PURE__*/
                  __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(job) {
                    var res, json;
                    return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            _context.next = 2;
                            return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("".concat(url, "/job/").concat(job.path, "/lastBuild/api/json"), opts);

                          case 2:
                            res = _context.sent;
                            _context.next = 5;
                            return res.json();

                          case 5:
                            json = _context.sent;
                            return _context.abrupt("return", {
                              name: job.label,
                              url: json.url,
                              result: json.result
                            });

                          case 7:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee, this);
                  }));

                  return function (_x) {
                    return _ref3.apply(this, arguments);
                  };
                }()));

              case 5:
                builds = _context2.sent;
                this.setState({
                  error: false,
                  loading: false,
                  builds: builds
                });
                _context2.next = 12;
                break;

              case 9:
                _context2.prev = 9;
                _context2.t0 = _context2["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 12:
                _context2.prev = 12;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context2.finish(12);

              case 15:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[2, 9, 12, 15]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          loading = _state.loading,
          error = _state.error,
          builds = _state.builds;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__widget__["a" /* default */], {
        title: title,
        error: error,
        loading: loading,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 96
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["c" /* default */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 97
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tbody", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 98
        }
      }, builds && builds.map(function (build) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
          key: "jenkins-".concat(build.name),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 100
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 101
          }
        }, build.name), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 102
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("a", {
          href: build.url,
          title: build.result,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 103
          }
        }, build.result ? __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(JenkinsBadge, {
          status: build.result,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 106
          }
        }) : __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__loading_indicator__["a" /* default */], {
          size: "small",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 107
          }
        }))));
      }))));
    }
  }]);

  return Jenkins;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(Jenkins, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 60 * 5,
    title: 'Jenkins'
  }
});


/***/ }),

/***/ "./components/widgets/jira/issue-count.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return JiraIssueCount; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__widget__ = __webpack_require__("./components/widget.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__counter__ = __webpack_require__("./components/counter.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__lib_auth__ = __webpack_require__("./lib/auth.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\jira\\issue-count.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }







var schema = Object(__WEBPACK_IMPORTED_MODULE_3_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  query: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["number"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])(),
  authKey: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()
});

var JiraIssueCount =
/*#__PURE__*/
function (_Component) {
  _inherits(JiraIssueCount, _Component);

  function JiraIssueCount() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, JiraIssueCount);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = JiraIssueCount.__proto__ || Object.getPrototypeOf(JiraIssueCount)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        count: 0,
        error: false,
        loading: true
      }
    }), _temp));
  }

  _createClass(JiraIssueCount, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, authKey, url, query, opts, res, json;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, authKey = _props.authKey, url = _props.url, query = _props.query;
                opts = authKey ? {
                  headers: Object(__WEBPACK_IMPORTED_MODULE_6__lib_auth__["a" /* basicAuthHeader */])(authKey)
                } : {}; // const opts = { headers: new Headers(basicAuthHeader(authKey)) }
                //const opts = { headers: new Headers(basicAuthHeader(authKey)) }
                //console.log(opts)

                _context.prev = 2;
                _context.next = 5;
                return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("".concat(url, "/jira/rest/api/2/search?jql=").concat(query), opts);

              case 5:
                res = _context.sent;
                _context.next = 8;
                return res.json();

              case 8:
                json = _context.sent;
                this.setState({
                  count: json.total,
                  error: false,
                  loading: false
                });
                _context.next = 15;
                break;

              case 12:
                _context.prev = 12;
                _context.t0 = _context["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 15:
                _context.prev = 15;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(15);

              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 12, 15, 18]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }() // componentDidMount () {
    //   var proxyUrl = 'https://cors-anywhere.herokuapp.com/'
    // }

  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          count = _state.count,
          error = _state.error,
          loading = _state.loading;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 68
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__counter__["a" /* default */], {
        value: count,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 69
        }
      }));
    }
  }]);

  return JiraIssueCount;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(JiraIssueCount, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 60 * 5,
    title: 'JIRA Issue Count'
  }
});


/***/ }),

/***/ "./components/widgets/pagespeed-insights/score.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__circle_progress__ = __webpack_require__("./components/circle-progress.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__widget__ = __webpack_require__("./components/widget.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\pagespeed-insights\\score.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }






var schema = Object(__WEBPACK_IMPORTED_MODULE_3_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  filterThirdPartyResources: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["boolean"])(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["number"])(),
  strategy: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()
});

var PageSpeedInsightsScore =
/*#__PURE__*/
function (_Component) {
  _inherits(PageSpeedInsightsScore, _Component);

  function PageSpeedInsightsScore() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, PageSpeedInsightsScore);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = PageSpeedInsightsScore.__proto__ || Object.getPrototypeOf(PageSpeedInsightsScore)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        score: 0,
        loading: true,
        error: false
      }
    }), _temp));
  }

  _createClass(PageSpeedInsightsScore, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, url, filterThirdPartyResources, strategy, searchParams, res, json;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, url = _props.url, filterThirdPartyResources = _props.filterThirdPartyResources, strategy = _props.strategy;
                searchParams = ["url=".concat(url), "filter_third_party_resources=".concat(filterThirdPartyResources), "strategy=".concat(strategy)].join('&');
                _context.prev = 2;
                _context.next = 5;
                return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?".concat(searchParams));

              case 5:
                res = _context.sent;
                _context.next = 8;
                return res.json();

              case 8:
                json = _context.sent;
                //console.log(json);
                this.setState({
                  error: false,
                  loading: false,
                  score: json.ruleGroups.SPEED.score
                });
                _context.next = 15;
                break;

              case 12:
                _context.prev = 12;
                _context.t0 = _context["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 15:
                _context.prev = 15;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(15);

              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 12, 15, 18]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          error = _state.error,
          loading = _state.loading,
          score = _state.score;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 68
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__circle_progress__["a" /* default */], {
        value: score,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 69
        }
      }));
    }
  }]);

  return PageSpeedInsightsScore;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(PageSpeedInsightsScore, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    filterThirdPartyResources: false,
    interval: 1000 * 60 * 60 * 12,
    strategy: 'desktop',
    title: 'PageSpeed Score'
  }
});


/***/ }),

/***/ "./components/widgets/pagespeed-insights/stats.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__table__ = __webpack_require__("./components/table.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__widget__ = __webpack_require__("./components/widget.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\pagespeed-insights\\stats.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }






var schema = Object(__WEBPACK_IMPORTED_MODULE_3_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])().required(),
  filterThirdPartyResources: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["boolean"])(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["number"])(),
  strategy: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_3_yup__["string"])()
});

var PageSpeedInsightsStats =
/*#__PURE__*/
function (_Component) {
  _inherits(PageSpeedInsightsStats, _Component);

  function PageSpeedInsightsStats() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, PageSpeedInsightsStats);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = PageSpeedInsightsStats.__proto__ || Object.getPrototypeOf(PageSpeedInsightsStats)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        stats: {},
        loading: true,
        error: false
      }
    }), _temp));
  }

  _createClass(PageSpeedInsightsStats, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "bytesToKilobytes",
    value: function bytesToKilobytes(bytes) {
      return bytes > 0 ? (bytes / 1024).toFixed(1) : 0;
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, url, filterThirdPartyResources, strategy, searchParams, res, json, pageStats, stats;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, url = _props.url, filterThirdPartyResources = _props.filterThirdPartyResources, strategy = _props.strategy;
                searchParams = ["url=".concat(url), "filter_third_party_resources=".concat(filterThirdPartyResources), "strategy=".concat(strategy)].join('&');
                _context.prev = 2;
                _context.next = 5;
                return __WEBPACK_IMPORTED_MODULE_2_isomorphic_unfetch___default()("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?".concat(searchParams));

              case 5:
                res = _context.sent;
                _context.next = 8;
                return res.json();

              case 8:
                json = _context.sent;
                pageStats = json.pageStats;
                stats = {
                  cssCount: pageStats.numberCssResources || 0,
                  cssSize: this.bytesToKilobytes(pageStats.cssResponseBytes),
                  htmlSize: this.bytesToKilobytes(pageStats.htmlResponseBytes),
                  imageSize: this.bytesToKilobytes(pageStats.imageResponseBytes),
                  javascriptCount: pageStats.numberJsResources || 0,
                  javascriptSize: this.bytesToKilobytes(pageStats.javascriptResponseBytes),
                  requestCount: pageStats.numberResources || 0,
                  requestSize: this.bytesToKilobytes(pageStats.totalRequestBytes),
                  otherSize: this.bytesToKilobytes(pageStats.otherResponseBytes)
                };
                this.setState({
                  error: false,
                  loading: false,
                  stats: stats
                });
                _context.next = 17;
                break;

              case 14:
                _context.prev = 14;
                _context.t0 = _context["catch"](2);
                this.setState({
                  error: true,
                  loading: false
                });

              case 17:
                _context.prev = 17;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(17);

              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 14, 17, 20]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          error = _state.error,
          loading = _state.loading,
          stats = _state.stats;
      var title = this.props.title;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 84
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["c" /* default */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 85
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tbody", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 86
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 87
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 88
        }
      }, "Request"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 89
        }
      }, stats.requestSize, " KB (", stats.requestCount, ")")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 92
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 93
        }
      }, "JavaScript"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 94
        }
      }, stats.javascriptSize, " KB (", stats.javascriptCount, ")")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 97
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 98
        }
      }, "CSS"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 99
        }
      }, stats.cssSize, " KB (", stats.cssCount, ")")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 102
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 103
        }
      }, "HTML"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 104
        }
      }, stats.htmlSize, " KB")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 107
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 108
        }
      }, "Image"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 109
        }
      }, stats.imageSize, " KB")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 112
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 113
        }
      }, "Other"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 114
        }
      }, stats.otherSize, " KB")))));
    }
  }]);

  return PageSpeedInsightsStats;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(PageSpeedInsightsStats, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    filterThirdPartyResources: false,
    interval: 1000 * 60 * 60 * 12,
    strategy: 'desktop',
    title: 'PageSpeed Stats'
  }
});


/***/ }),

/***/ "./components/widgets/sonarqube/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SonarQube; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__("@babel/runtime/regenerator");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_isomorphic_unfetch__ = __webpack_require__("isomorphic-unfetch");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_isomorphic_unfetch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_isomorphic_unfetch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__("yup");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__widget__ = __webpack_require__("./components/widget.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__table__ = __webpack_require__("./components/table.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__badge__ = __webpack_require__("./components/badge.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__lib_auth__ = __webpack_require__("./lib/auth.js");

var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\sonarqube\\index.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }










var alertColor = function alertColor(_ref) {
  var theme = _ref.theme,
      children = _ref.children;

  switch (children) {
    case 'ERROR':
      return theme.palette.errorColor;

    case 'WARN':
      return theme.palette.warnColor;

    default:
      // OK
      return theme.palette.successColor;
  }
};

var Alert = __WEBPACK_IMPORTED_MODULE_2_styled_components___default.a.span.withConfig({
  displayName: "sonarqube__Alert",
  componentId: "s1guu1e-0"
})(["color:", ";"], alertColor);

var sonarBadgeColor = function sonarBadgeColor(_ref2) {
  var theme = _ref2.theme,
      children = _ref2.children;

  switch (children) {
    case 'A':
      return theme.palette.successColor;

    case 'B':
      return theme.palette.successSecondaryColor;

    case 'C':
      return theme.palette.warnColor;

    case 'D':
      return theme.palette.warnSecondaryColor;

    case 'E':
      return theme.palette.errorColor;

    default:
      return 'transparent';
  }
};

var SonarBadge = __WEBPACK_IMPORTED_MODULE_2_styled_components___default()(__WEBPACK_IMPORTED_MODULE_7__badge__["a" /* default */]).withConfig({
  displayName: "sonarqube__SonarBadge",
  componentId: "s1guu1e-1"
})(["background-color:", ";"], sonarBadgeColor);
var schema = Object(__WEBPACK_IMPORTED_MODULE_4_yup__["object"])().shape({
  url: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])().required(),
  componentKey: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])().required(),
  interval: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["number"])(),
  title: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])(),
  authKey: Object(__WEBPACK_IMPORTED_MODULE_4_yup__["string"])()
});

var SonarQube =
/*#__PURE__*/
function (_Component) {
  _inherits(SonarQube, _Component);

  function SonarQube() {
    var _ref3;

    var _temp, _this;

    _classCallCheck(this, SonarQube);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref3 = SonarQube.__proto__ || Object.getPrototypeOf(SonarQube)).call.apply(_ref3, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        measures: [],
        loading: true,
        error: false
      }
    }), Object.defineProperty(_assertThisInitialized(_this), "getMetricValue", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(measures, metricKey) {
        var result = measures.filter(function (measure) {
          return measure.metric === metricKey;
        });
        return result.length ? result[0].value : '';
      }
    }), Object.defineProperty(_assertThisInitialized(_this), "getRatingValue", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(measures, metricKey) {
        var value = _this.getMetricValue(measures, metricKey);

        switch (value) {
          case '1.0':
            return 'A';

          case '2.0':
            return 'B';

          case '3.0':
            return 'C';

          case '4.0':
            return 'D';

          case '5.0':
            return 'E';
        }

        return '?';
      }
    }), _temp));
  }

  _createClass(SonarQube, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      schema.validate(this.props).then(function () {
        return _this2.fetchInformation();
      }).catch(function (err) {
        console.error("".concat(err.name, " @ ").concat(_this2.constructor.name), err.errors);

        _this2.setState({
          error: true,
          loading: false
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "fetchInformation",
    value: function () {
      var _fetchInformation = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee() {
        var _this3 = this;

        var _props, authKey, url, componentKey, opts, metricKeys, res, json;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _props = this.props, authKey = _props.authKey, url = _props.url, componentKey = _props.componentKey;
                opts = authKey ? {
                  headers: Object(__WEBPACK_IMPORTED_MODULE_8__lib_auth__["a" /* basicAuthHeader */])(authKey)
                } : {}; // https://docs.sonarqube.org/display/SONAR/Metric+Definitions

                metricKeys = ['alert_status', 'reliability_rating', 'bugs', 'security_rating', 'vulnerabilities', 'sqale_rating', 'code_smells', 'coverage', 'duplicated_lines_density'].join(',');
                _context.prev = 3;
                _context.next = 6;
                return __WEBPACK_IMPORTED_MODULE_3_isomorphic_unfetch___default()("".concat(url, "/api/measures/component?componentKey=").concat(componentKey, "&metricKeys=").concat(metricKeys), opts);

              case 6:
                res = _context.sent;
                _context.next = 9;
                return res.json();

              case 9:
                json = _context.sent;
                this.setState({
                  error: false,
                  loading: false,
                  measures: json.component.measures
                });
                _context.next = 16;
                break;

              case 13:
                _context.prev = 13;
                _context.t0 = _context["catch"](3);
                this.setState({
                  error: true,
                  loading: false
                });

              case 16:
                _context.prev = 16;
                this.timeout = setTimeout(function () {
                  return _this3.fetchInformation();
                }, this.props.interval);
                return _context.finish(16);

              case 19:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[3, 13, 16, 19]]);
      }));

      return function fetchInformation() {
        return _fetchInformation.apply(this, arguments);
      };
    }()
  }, {
    key: "render",
    value: function render() {
      var _state = this.state,
          error = _state.error,
          loading = _state.loading,
          measures = _state.measures;
      var title = this.props.title;
      var alertStatus = this.getMetricValue(measures, 'alert_status');
      var reliabilityRating = this.getRatingValue(measures, 'reliability_rating');
      var bugs = this.getMetricValue(measures, 'bugs');
      var securityRating = this.getRatingValue(measures, 'security_rating');
      var vulnerabilities = this.getMetricValue(measures, 'vulnerabilities');
      var sqaleRating = this.getRatingValue(measures, 'sqale_rating');
      var codeSmells = this.getMetricValue(measures, 'code_smells');
      var coverage = this.getMetricValue(measures, 'coverage');
      var duplicatedLinesDensity = this.getMetricValue(measures, 'duplicated_lines_density');
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__widget__["a" /* default */], {
        title: title,
        loading: loading,
        error: error,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 139
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["c" /* default */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 140
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tbody", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 141
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 142
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 143
        }
      }, "Quality Gate:"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 144
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(Alert, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 144
        }
      }, alertStatus))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 147
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 148
        }
      }, "Reliability:"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 149
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(SonarBadge, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 150
        }
      }, reliabilityRating), " ", __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("small", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 150
        }
      }, "(", bugs, ")"))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 154
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 155
        }
      }, "Security:"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 156
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(SonarBadge, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 157
        }
      }, securityRating), " ", __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("small", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 157
        }
      }, "(", vulnerabilities, ")"))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 161
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 162
        }
      }, "Maintainability:"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 163
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(SonarBadge, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 164
        }
      }, sqaleRating), " ", __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("small", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 164
        }
      }, "(", codeSmells, ")"))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 168
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 169
        }
      }, "Coverage:"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 170
        }
      }, coverage, "%")), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("tr", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 173
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["b" /* Th */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 174
        }
      }, "Duplications:"), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__table__["a" /* Td */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 175
        }
      }, duplicatedLinesDensity, "%")))));
    }
  }]);

  return SonarQube;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

Object.defineProperty(SonarQube, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 60 * 5,
    title: 'SonarQube'
  }
});


/***/ }),

/***/ "./lib/auth.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return basicAuthHeader; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_js_base64__ = __webpack_require__("js-base64");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_js_base64___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_js_base64__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__auth__ = __webpack_require__("./auth.js");


var basicAuthHeader = function basicAuthHeader(key) {
  var credentials = __WEBPACK_IMPORTED_MODULE_1__auth__["a" /* default */][key];

  if (credentials) {
    var credential = __WEBPACK_IMPORTED_MODULE_0_js_base64__["Base64"].encode("".concat(credentials.username, ":").concat(credentials.password));
    return {
      'Authorization': "Basic ".concat(credential)
    };
  }

  throw new ReferenceError("No credentials found with key '".concat(key, "' in auth.js"));
};

/***/ }),

/***/ "./pages/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_dashboard__ = __webpack_require__("./components/dashboard.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("polished");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_polished__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__("styled-components");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_widgets_datetime__ = __webpack_require__("./components/widgets/datetime/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_widgets_pagespeed_insights_score__ = __webpack_require__("./components/widgets/pagespeed-insights/score.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_widgets_pagespeed_insights_stats__ = __webpack_require__("./components/widgets/pagespeed-insights/stats.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__ = __webpack_require__("./components/widgets/jira/issue-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__ = __webpack_require__("./components/widgets/sonarqube/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__ = __webpack_require__("./components/widgets/jenkins/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__ = __webpack_require__("./components/widgets/bitbucket/pull-request-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_widgets_elasticsearch_hit_count__ = __webpack_require__("./components/widgets/elasticsearch/hit-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_widgets_github_issue_count__ = __webpack_require__("./components/widgets/github/issue-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__styles_light_theme__ = __webpack_require__("./styles/light-theme.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__styles_dark_theme__ = __webpack_require__("./styles/dark-theme.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\pages\\index.js";



 // Widgets









 // Theme



var StyleWrapper = __WEBPACK_IMPORTED_MODULE_3_styled_components___default.a.main.withConfig({
  displayName: "pages__StyleWrapper",
  componentId: "wz8p2a-0"
})(["", " align-items:center;background-color:", ";color:", ";display:flex;flex-flow:row wrap;justify-content:flex-start;padding:0px;margin:1px;"], Object(__WEBPACK_IMPORTED_MODULE_2_polished__["size"])('49em'), function (props) {
  return props.theme.palette.backgroundColor;
}, function (props) {
  return props.theme.palette.textColor;
});
/* harmony default export */ __webpack_exports__["default"] = (function () {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_dashboard__["a" /* default */], {
    theme: __WEBPACK_IMPORTED_MODULE_14__styles_dark_theme__["a" /* default */],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 80
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 127
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 128
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 145
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 151
    }
  })));
});

/***/ }),

/***/ "./styles/dark-theme.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var colors = {
  grey400: '#bdbdbd',
  grey700: '#616161',
  grey800: '#424242',
  grey: '#303030',
  white: '#ffffff',
  cyan500: '#00bcd4',
  pinkA200: '#ff4081',
  red500: '#f44336',
  amber500: '#ffc107',
  green500: '#4caf50',
  orange500: '#ff9800',
  lime500: '#cddc39'
};
/* harmony default export */ __webpack_exports__["a"] = ({
  palette: {
    backgroundColor: colors.grey,
    borderColor: colors.grey700,
    textColor: colors.white,
    textInvertColor: colors.grey,
    canvasColor: colors.grey800,
    primaryColor: colors.cyan500,
    accentColor: colors.pinkA200,
    errorColor: colors.red500,
    warnColor: colors.amber500,
    warnSecondaryColor: colors.orange500,
    successColor: colors.green500,
    successSecondaryColor: colors.lime500,
    disabledColor: colors.grey400
  }
});

/***/ }),

/***/ "./styles/light-theme.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var colors = {
  grey50: '#fafafa',
  grey200: '#eeeeee',
  grey400: '#bdbdbd',
  grey900: '#212121',
  white: '#ffffff',
  cyan500: '#00bcd4',
  pinkA200: '#ff4081',
  redA700: '#d50000',
  amberA700: '#ffab00',
  greenA700: '#00c853',
  lightGreenA700: '#64dd17',
  orangeA700: '#ff6d00'
};
/* unused harmony default export */ var _unused_webpack_default_export = ({
  palette: {
    backgroundColor: colors.grey50,
    borderColor: colors.grey200,
    textColor: colors.grey900,
    textInvertColor: colors.grey50,
    canvasColor: colors.white,
    primaryColor: colors.cyan500,
    accentColor: colors.pinkA200,
    errorColor: colors.redA700,
    warnColor: colors.amberA700,
    warnSecondaryColor: colors.orangeA700,
    successColor: colors.greenA700,
    successSecondaryColor: colors.lightGreenA700,
    disabledColor: colors.grey400
  }
});

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./pages/index.js");


/***/ }),

/***/ "@babel/runtime/regenerator":
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "isomorphic-unfetch":
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),

/***/ "js-base64":
/***/ (function(module, exports) {

module.exports = require("js-base64");

/***/ }),

/***/ "next/head":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "polished":
/***/ (function(module, exports) {

module.exports = require("polished");

/***/ }),

/***/ "react":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "styled-components":
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "tinytime":
/***/ (function(module, exports) {

module.exports = require("tinytime");

/***/ }),

/***/ "yup":
/***/ (function(module, exports) {

module.exports = require("yup");

/***/ })

/******/ });
//# sourceMappingURL=index.js.map