webpackHotUpdate(5,{

/***/ "./static/projects.json":
/***/ (function(module, exports) {

module.exports = [{"name":"Project A","jira-jql":"project = ELCAVNPC AND type = Improvement","bitbucket-project":"","bitbucket-history":"","sonarqube-componentKey":"","jenkins-jobs":[{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"},{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"}]},{"name":"Project B","jira-jql":"project = ELCAVNPC AND type = Improvement","bitbucket-project":"","bitbucket-history":"","sonarqube-componentKey":"","jenkins-jobs":[{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"},{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"}]},{"name":"Project B","jira-jql":"project = ELCAVNPC AND type = Improvement","bitbucket-project":"","bitbucket-history":"","sonarqube-componentKey":""}]

/***/ })

})
//# sourceMappingURL=5.ee99e8903177ae00ba55.hot-update.js.map