webpackHotUpdate(5,{

/***/ "./components/dashboard.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_head__ = __webpack_require__("./node_modules/next/head.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_head___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_next_head__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("./node_modules/polished/dist/polished.es.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.es.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\dashboard.js";

var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n\n  html {\n    font-family: 'Roboto', sans-serif;\n  }\n"]);



function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }





Object(__WEBPACK_IMPORTED_MODULE_3_styled_components__["d" /* injectGlobal */])(_templateObject, Object(__WEBPACK_IMPORTED_MODULE_2_polished__["a" /* normalize */])());
var Container = __WEBPACK_IMPORTED_MODULE_3_styled_components__["c" /* default */].main.withConfig({
  displayName: "dashboard__Container",
  componentId: "c3g5ri-0"
})(["align-items:center;background-color:", ";color:", ";display:flex;flex-flow:row wrap;justify-content:flex-start;padding:1em;margin:1em;"], function (props) {
  return props.theme.palette.borderColor;
}, function (props) {
  return props.theme.palette.textColor;
});
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var children = _ref.children,
      theme = _ref.theme;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_styled_components__["b" /* ThemeProvider */], {
    theme: theme,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_next_head___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("link", {
    href: "https://fonts.googleapis.com/css?family=Roboto:300,400,500",
    rel: "stylesheet",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  })), children));
});

/***/ })

})
//# sourceMappingURL=5.6925dd2f6f9a93752055.hot-update.js.map