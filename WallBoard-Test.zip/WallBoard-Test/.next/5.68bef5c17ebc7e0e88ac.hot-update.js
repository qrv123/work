webpackHotUpdate(5,{

/***/ "./components/widgets/datetime/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_tinytime__ = __webpack_require__("./node_modules/tinytime/dist/tinytime.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_tinytime___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_tinytime__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.es.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__widget__ = __webpack_require__("./components/widget.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widgets\\datetime\\index.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }





var TimeItem = __WEBPACK_IMPORTED_MODULE_2_styled_components__["c" /* default */].div.withConfig({
  displayName: "datetime__TimeItem",
  componentId: "s1ynucdp-0"
})(["font-size:4em;text-align:center;"]);
var DateItem = __WEBPACK_IMPORTED_MODULE_2_styled_components__["c" /* default */].div.withConfig({
  displayName: "datetime__DateItem",
  componentId: "s1ynucdp-1"
})(["font-size:1.5em;text-align:center;"]);

var DateTime =
/*#__PURE__*/
function (_Component) {
  _inherits(DateTime, _Component);

  function DateTime() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, DateTime);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = DateTime.__proto__ || Object.getPrototypeOf(DateTime)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        date: new Date()
      }
    }), _temp));
  }

  _createClass(DateTime, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      var interval = this.props.interval;
      this.timeout = setTimeout(function () {
        return _this2.setState({
          date: new Date()
        });
      }, interval);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      clearTimeout(this.timeout);
    }
  }, {
    key: "render",
    value: function render() {
      var date = this.state.date;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__widget__["a" /* default */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(TimeItem, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        }
      }, __WEBPACK_IMPORTED_MODULE_1_tinytime___default()('{H}:{mm}').render(date)), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(DateItem, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        }
      }, __WEBPACK_IMPORTED_MODULE_1_tinytime___default()('{DD}.{Mo}.{YYYY}').render(date)));
    }
  }]);

  return DateTime;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

Object.defineProperty(DateTime, "defaultProps", {
  configurable: true,
  enumerable: true,
  writable: true,
  value: {
    interval: 1000 * 10
  }
});


/***/ }),

/***/ "./pages/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_dashboard__ = __webpack_require__("./components/dashboard.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_widgets_datetime__ = __webpack_require__("./components/widgets/datetime/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_widgets_pagespeed_insights_score__ = __webpack_require__("./components/widgets/pagespeed-insights/score.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_widgets_pagespeed_insights_stats__ = __webpack_require__("./components/widgets/pagespeed-insights/stats.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_widgets_jira_issue_count__ = __webpack_require__("./components/widgets/jira/issue-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_widgets_sonarqube__ = __webpack_require__("./components/widgets/sonarqube/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_widgets_jenkins__ = __webpack_require__("./components/widgets/jenkins/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_widgets_bitbucket_pull_request_count__ = __webpack_require__("./components/widgets/bitbucket/pull-request-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_widgets_elasticsearch_hit_count__ = __webpack_require__("./components/widgets/elasticsearch/hit-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_widgets_github_issue_count__ = __webpack_require__("./components/widgets/github/issue-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__styles_light_theme__ = __webpack_require__("./styles/light-theme.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__styles_dark_theme__ = __webpack_require__("./styles/dark-theme.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\pages\\index.js";

 // Widgets









 // Theme


 // import darkTheme from '../styles/dark-theme'

var car = 5;
/* harmony default export */ __webpack_exports__["default"] = (function () {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_dashboard__["a" /* default */], {
    theme: __WEBPACK_IMPORTED_MODULE_12__styles_dark_theme__["a" /* default */],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }));
});
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=5.68bef5c17ebc7e0e88ac.hot-update.js.map