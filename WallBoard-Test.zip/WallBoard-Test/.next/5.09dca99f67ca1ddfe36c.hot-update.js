webpackHotUpdate(5,{

/***/ "./static/projects.json":
/***/ (function(module, exports) {

module.exports = [{"name":"Project A","jira-jql":"project = ELCAVNPC AND type = Improvement","bitbucket-project":"","bitbucket-history":"","sonarqube-componentKey":"","jenkins-jobs":[{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"},{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"}]},{"name":"Project B","jira-jql":"project = ELCAVNPC AND type = Improvement","bitbucket-project":"","bitbucket-history":"","sonarqube-componentKey":"","jenkins-jobs":[{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"},{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"}]},{"name":"Project B","jira-jql":"project = ELCAVNPC AND type = Improvement","bitbucket-project":"","bitbucket-history":"","sonarqube-componentKey":"","jenkins-jobs":[{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"},{"label":"aaaa","path":"prj_elca-git-training+build-on-commit"}]}]

/***/ })

})
//# sourceMappingURL=5.09dca99f67ca1ddfe36c.hot-update.js.map