webpackHotUpdate(5,{

/***/ "./components/widget.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.es.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("./node_modules/polished/dist/polished.es.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__loading_indicator__ = __webpack_require__("./components/loading-indicator.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__error_icon__ = __webpack_require__("./components/error-icon.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\components\\widget.js";





var Container = __WEBPACK_IMPORTED_MODULE_1_styled_components__["c" /* default */].div.withConfig({
  displayName: "widget__Container",
  componentId: "rztqo9-0"
})(["", " align-items:center;background-color:", ";border:1px solid ", ";display:flex;flex-direction:column;justify-content:center;margin:1em;margin-bottom:1px;padding:1em;"], Object(__WEBPACK_IMPORTED_MODULE_2_polished__["b" /* size */])('19em'), function (props) {
  return props.theme.palette.canvasColor;
}, function (props) {
  return props.theme.palette.borderColor;
});
var Title = __WEBPACK_IMPORTED_MODULE_1_styled_components__["c" /* default */].h1.withConfig({
  displayName: "widget__Title",
  componentId: "rztqo9-1"
})(["text-align:center;"]);
/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var children = _ref.children,
      _ref$error = _ref.error,
      error = _ref$error === void 0 ? false : _ref$error,
      _ref$loading = _ref.loading,
      loading = _ref$loading === void 0 ? false : _ref$loading,
      _ref$title = _ref.title,
      title = _ref$title === void 0 ? '' : _ref$title;
  var content;

  if (loading) {
    content = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__loading_indicator__["a" /* default */], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 27
      }
    });
  } else if (error) {
    content = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__error_icon__["a" /* default */], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 29
      }
    });
  } else {
    content = __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 31
      }
    }, children);
  }

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, title ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Title, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, title) : '', content);
});

/***/ })

})
//# sourceMappingURL=5.ff366ca0e1bef8cdf731.hot-update.js.map