webpackHotUpdate(5,{

/***/ "./pages/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_dashboard__ = __webpack_require__("./components/dashboard.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_polished__ = __webpack_require__("./node_modules/polished/dist/polished.es.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.es.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_widgets_datetime__ = __webpack_require__("./components/widgets/datetime/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_widgets_pagespeed_insights_score__ = __webpack_require__("./components/widgets/pagespeed-insights/score.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_widgets_pagespeed_insights_stats__ = __webpack_require__("./components/widgets/pagespeed-insights/stats.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__ = __webpack_require__("./components/widgets/jira/issue-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__ = __webpack_require__("./components/widgets/sonarqube/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__ = __webpack_require__("./components/widgets/jenkins/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__ = __webpack_require__("./components/widgets/bitbucket/pull-request-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_widgets_elasticsearch_hit_count__ = __webpack_require__("./components/widgets/elasticsearch/hit-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_widgets_github_issue_count__ = __webpack_require__("./components/widgets/github/issue-count.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__styles_light_theme__ = __webpack_require__("./styles/light-theme.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__styles_dark_theme__ = __webpack_require__("./styles/dark-theme.js");
var _jsxFileName = "D:\\projects\\WallBoard-Test\\pages\\index.js";



 // Widgets









 // Theme



var StyleWrapper = __WEBPACK_IMPORTED_MODULE_3_styled_components__["c" /* default */].main.withConfig({
  displayName: "pages__StyleWrapper",
  componentId: "wz8p2a-0"
})(["", " align-items:center;background-color:", ";color:", ";display:center;flex-flow:row wrap;justify-content:flex-start;padding:1px;margin:1px;"], Object(__WEBPACK_IMPORTED_MODULE_2_polished__["b" /* size */])('49em'), function (props) {
  return props.theme.palette.backgroundColor;
}, function (props) {
  return props.theme.palette.textColor;
});
/* harmony default export */ __webpack_exports__["default"] = (function () {
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components_dashboard__["a" /* default */], {
    theme: __WEBPACK_IMPORTED_MODULE_14__styles_dark_theme__["a" /* default */],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 80
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyleWrapper, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 127
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_widgets_jira_issue_count__["a" /* default */], {
    title: "JIRA Open Bugs",
    authKey: "jira",
    url: "http://192.168.222.101:8080" + '/https://projectportal.elca.ch',
    query: "project = ELCAVNPC AND type = Improvement",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 128
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__components_widgets_bitbucket_pull_request_count__["a" /* default */], {
    title: "Bitbucket Open PR",
    authKey: "bitbucket",
    url: "http://192.168.222.101:8080" + '/https://git.elcanet.local',
    project: "ELCAVN-MANAGEMENT-TOOL",
    repository: "project-wallboard",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_widgets_sonarqube__["a" /* default */], {
    authKey: "sonarqube",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/sonar',
    componentKey: "prj_ofac-portals-sonar",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 145
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_widgets_jenkins__["a" /* default */], {
    authKey: "jenkins",
    url: "http://192.168.222.101:8080" + '/http://ci.elcanet.local/jenkins',
    jobs: [{
      label: 'aaaa',
      path: 'prj_elca-git-training+build-on-commit'
    }, {
      label: 'bbbb',
      path: 'prj_elcavn-newcomers+Build+java3'
    }],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 151
    }
  })));
});
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=5.f4118628d49d21f33945.hot-update.js.map