import React from "react";

export default ({ text }) => (
  <div>
    <h1>Simple Lorem Story Test 2 {text}</h1>
  </div>
);
